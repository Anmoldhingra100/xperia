from django.shortcuts import render
from django.http import HttpResponse
from django.utils import timezone
from django.db.models.functions import TruncWeek
from solar_app.models import MySolarrr,solargeneration,Temperature,Efficiency,Humidity,Performance,UV_Indexx,Production,Irradiance,Solar_Plant,weather,Sales_and_revenue
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils import timezone
from datetime import timedelta
from solar_app.models import MySolarrr
from .serializers import EnergyDataSerializer
from django.utils import timezone
from .serializers import MySolarrrSerializer,HumiditySerializer,solargenerationSerializer,TemperatureSerializer,PerformanceSerializer,UV_IndexxSerializer,ProductionSerializer,IrradianceSerializer,SalesandrevenueSerializer,weatherSerializer
from rest_framework import viewsets
from rest_framework import generics
from .serializers import MySolarrrSerializer
from rest_framework import status
from .serializers import EfficiencySerializer, SolarPlantSerializer
from django.db.models import Sum,Avg,Max
from django.db.models.functions import TruncDate 
from django.db import connection
from datetime import datetime
from django.utils.dateparse import parse_date

def home_page_view(request):
    return request(request,'solarr.html')



class WeeklyDataAPIView(APIView):
    def get(self, request):
        today = timezone.now()
        start_of_week = today - timedelta(days=today.weekday())  # Monday of the current week
        end_of_week = start_of_week + timedelta(days=6)  # Sunday of the current week

        # Querying the database for records within the current week
        weekly_data = MySolarrr.objects.filter(date__range=[start_of_week, end_of_week])
        serializer = EnergyDataSerializer(weekly_data, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)







class RecordsLastSevenDaysView(APIView):
    def get(self, request, *args, **kwargs):
        now = timezone.now()
        seven_days_ago = now - timedelta(days=7)  # Changed to 7 days as the class name suggests

        # Query all models
        solarrr_records = MySolarrr.objects.filter(date__gte=seven_days_ago, date__lte=now)
        irradiance_records = Irradiance.objects.filter(date__gte=seven_days_ago, date__lte=now)
        humidity_records = Humidity.objects.filter(date__gte=seven_days_ago, date__lte=now)
        Efficiency_records = Efficiency.objects.filter(date__gte=seven_days_ago, date__lte=now)
        temperature_records = Temperature.objects.filter(date__gte=seven_days_ago, date__lte=now)
        Performance_records = Performance.objects.filter(date__gte=seven_days_ago, date__lte=now)
        uv_indexx_records = UV_Indexx.objects.filter(date__gte=seven_days_ago, date__lte=now)
        solar_generation_records = solargeneration.objects.filter(date__gte=seven_days_ago, date__lte=now)
        production_records = Production.objects.filter(date__gte=seven_days_ago, date__lte=now)

        # Serialize the data
        data = {
            'solarrr': MySolarrrSerializer(solarrr_records, many=True).data,
            'irradiance': IrradianceSerializer(irradiance_records, many=True).data,
            'humidity': HumiditySerializer(humidity_records, many=True).data,
            'Efficiency': EfficiencySerializer(Efficiency_records, many=True).data,
            'temperature': TemperatureSerializer(temperature_records, many=True).data,
            'Performance': PerformanceSerializer(Performance_records, many=True).data,
            'uv_indexx': UV_IndexxSerializer(uv_indexx_records, many=True).data,
            'solar_generation': solargenerationSerializer(solar_generation_records, many=True).data,
            'production': ProductionSerializer(production_records, many=True).data,
        }

        return Response(data, status=status.HTTP_200_OK)


class solargenerationListCreateView(generics.ListCreateAPIView):
    queryset = solargeneration.objects.all()
    serializer_class = solargenerationSerializer



class solargenerationHourlyView(generics.GenericAPIView):
    serializer_class = solargenerationSerializer

    def get(self, request, *args, **kwargs):
        date = self.kwargs.get('date')
        try:
            solar_data = solargeneration.objects.get(date=date)
        except solargeneration.DoesNotExist:
            return Response({"detail": "Data not found for the given date."}, status=status.HTTP_404_NOT_FOUND)

        serializer = self.get_serializer(solar_data)
        return Response(serializer.data)


class PerformanceHourlyView(generics.GenericAPIView):
    serializer_class = PerformanceSerializer

    def get(self, request, *args, **kwargs):
        date = self.kwargs.get('date')
        try:
            performance_data = Performance.objects.get(date=date)
        except Performance.DoesNotExist:
            return Response({"detail": "Data not found for the given date."}, status=status.HTTP_404_NOT_FOUND)

        serializer = self.get_serializer(performance_data)
        return Response(serializer.data)


class TemperatureHourlyData(APIView):
    def get(self, request, format=None):
        date = request.query_params.get('date')
        if not date:
            return Response({"error": "Date parameter is required."}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            temperatures = Temperature.objects.get(date=date)
        except Temperature.DoesNotExist:
            return Response({"error": "No data found for the given date."}, status=status.HTTP_404_NOT_FOUND)

        serializer = TemperatureSerializer(temperatures)
        return Response(serializer.data)





class HumidityHourlyData(APIView):
    def get(self, request, *args, **kwargs):
        date = request.query_params.get('date')
        if not date:
            return Response({"error": "Date parameter is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Fetch data from the database based on the date
            humidity_data = Humidity.objects.get(date=date)
        except Humidity.DoesNotExist:
            return Response({"error": "No data found for the given date"}, status=status.HTTP_404_NOT_FOUND)

        # Serialize the data
        serializer = HumiditySerializer(humidity_data)
        return Response(serializer.data)





class EfficiencyHourlyData(APIView):
    def get(self, request, *args, **kwargs):
        date = request.query_params.get('date')
        if not date:
            return Response({"error": "Date parameter is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            efficiency_data = Efficiency.objects.get(date=date)
        except Efficiency.DoesNotExist:
            return Response({"error": "No data found for the given date"}, status=status.HTTP_404_NOT_FOUND)

        serializer = EfficiencySerializer(efficiency_data)
        return Response(serializer.data)










class SolarPlantListView(APIView):
    def get(self, request, format=None):
        # Extract date parameter from the query string
        date = request.query_params.get('date', None)
        
        # Filter the queryset based on the date parameter
        if date:
            try:
                # Assume date is in the format YYYY-MM-DD
                queryset = Solar_Plant.objects.filter(date__date=date)
            except ValueError:
                return Response({'error': 'Invalid date format. Use YYYY-MM-DD.'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            queryset = Solar_Plant.objects.all()

        
        

        # Serialize the detailed data
        serializer = SolarPlantSerializer(queryset, many=True)
        detailed_data = serializer.data

        # Add aggregated sums to the response
        response_data = {
            'details': detailed_data,
            
        }

        return Response(response_data)



class DatewiseSumAPIView(APIView):
    def get(self, request, format=None):
        # Build the queryset without date filtering
        queryset = Solar_Plant.objects.annotate(truncated_date=TruncDate('date'))

        # Annotate and aggregate the data
        data = (queryset
                .values('truncated_date')
                .annotate(
                    total_energy_distribution=Sum('Energy_Distribution'),
                    total_energy_consumption=Sum('Energy_Consumption'),
                    total_energy_generation=Sum('Energy_generation'),
                    average_invertor_performance=Avg('Invertor_performance'),
                    total_fault_report=Sum('Fault_report')
                )
                .order_by('truncated_date'))

        # Format the decimal places
        formatted_data = []
        for item in data:
            formatted_item = {
                'truncated_date': item['truncated_date'],
                'total_energy_distribution': round(item['total_energy_distribution'], 2) if item['total_energy_distribution'] is not None else None,
                'total_energy_consumption': round(item['total_energy_consumption'], 2) if item['total_energy_consumption'] is not None else None,
                'total_energy_generation': round(item['total_energy_generation'], 2) if item['total_energy_generation'] is not None else None,
                'average_invertor_performance': round(item['average_invertor_performance'], 2) if item['average_invertor_performance'] is not None else None,
                'total_fault_report': round(item['total_fault_report'], 2) if item['total_fault_report'] is not None else None,
            }
            formatted_data.append(formatted_item)

        return Response(formatted_data)



class weatherAPIView(APIView):
    def get(self, request, format=None):
        # Retrieve the data and perform the aggregation
        sdata = (weather.objects
                .annotate(truncated_date=TruncDate('date'))
                .values('truncated_date')
                .annotate(
                    average_Humidity=Avg('Humidity'),
                    maximum_UV_Index=Max('UV_Index'),
                    average_Temperature=Avg('Temperature'),
                    average_Irradiance=Avg('Irradiance'),
                    chances_of_Rain_prediction=Avg('Rain_prediction'),
                )
                .order_by('truncated_date'))

        # Round the decimal places to 2 for each field
        for entry in sdata:
            entry['average_Humidity'] = round(entry['average_Humidity'], 2)
            entry['maximum_UV_Index'] = round(entry['maximum_UV_Index'], 2)
            entry['average_Temperature'] = round(entry['average_Temperature'], 2)
            entry['average_Irradiance'] = round(entry['average_Irradiance'], 2)
            entry['chances_of_Rain_prediction'] = round(entry['chances_of_Rain_prediction'], 2)

        return Response(sdata)


class SalesAndRevenueSumAPIView(APIView):
    def get(self, request, format=None):
        # Extract start_date and end_date from query parameters
        start_date_str = request.query_params.get('start_date')
        end_date_str = request.query_params.get('end_date')

        # Parse dates
        start_date = parse_date(start_date_str) if start_date_str else None
        end_date = parse_date(end_date_str) if end_date_str else None

        # Basic validation
        if start_date and end_date:
            if start_date > end_date:
                return Response({'error': 'start_date cannot be after end_date.'}, status=400)
            date_condition = "WHERE DATE(date) BETWEEN %s AND %s"
            date_params = [start_date, end_date]
        else:
            date_condition = ""
            date_params = []

        # Use a cursor to execute the query
        with connection.cursor() as cursor:
            query = f"""
                SELECT 
                    DATE(date) AS truncated_date,
                    SUM(Revenue) AS total_Revenue,
                    SUM(Sales) AS total_Sales,
                    SUM(Profit) AS total_Profit,
                    SUM(Losses) AS total_Losses,
                    SUM(Maintainance_cost) AS total_Maintainance_cost
                FROM solar_app_sales_and_revenue
                {date_condition}
                GROUP BY truncated_date
                ORDER BY truncated_date
            """
            cursor.execute(query, date_params)
            rows = cursor.fetchall()

        # Convert rows to dict format
        srdata = [
            {
                'truncated_date': row[0],
                'total_Revenue': row[1],
                'total_Sales': row[2],
                'total_Profit': row[3],
                'total_Losses': row[4],
                'total_Maintainance_cost': row[5],
            }
            for row in rows
        ]

        return Response(srdata)




class weatherListView(APIView):
    def get(self, request, format=None):
        # Extract date parameters from the query string
        start_date_str = request.query_params.get('start_date', None)
        end_date_str = request.query_params.get('end_date', None)
        
        try:
            # Parse dates if provided
            if start_date_str:
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            else:
                start_date = None
            
            if end_date_str:
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
            else:
                end_date = None
        except ValueError:
            return Response({'error': 'Invalid date format. Use YYYY-MM-DD.'}, status=status.HTTP_400_BAD_REQUEST)
        
        # Filter the queryset based on the date range
        if start_date and end_date:
            queryset = weather.objects.filter(date__date__range=(start_date, end_date))
        elif start_date:
            queryset = weather.objects.filter(date__date__gte=start_date)
        elif end_date:
            queryset = weather.objects.filter(date__date__lte=end_date)
        else:
            queryset = weather.objects.all()
        
        # Serialize the detailed data
        serializer = weatherSerializer(queryset, many=True)
        detailed_data = serializer.data
        
        # Construct the response data
        response_data = {
            'details': detailed_data,
        }

        return Response(response_data)






class weatherAverageAPIView(APIView):
    def get(self, request, format=None):
        sdata = (weather.objects
                .annotate(truncated_date=TruncDate('date'))
                .values('truncated_date')
                .annotate(
                    average_Humidity=Avg('Humidity'),
                    average_Index=Avg('UV_Index'),
                    average_Temperature=Avg('Temperature'),
                    average_Irradiance=Avg('Irradiance'),
                    average_Rain_prediction=Avg('Rain_prediction'),
                )
                .order_by('truncated_date'))

        # Round the aggregated values to 2 decimal places
        rounded_data = [
            {
                'truncated_date': entry['truncated_date'],
                'average_Humidity': round(entry['average_Humidity'], 2),
                'average_Index': round(entry['average_Index'], 2),
                'average_Temperature': round(entry['average_Temperature'], 2),
                'average_Irradiance': round(entry['average_Irradiance'], 2),
                'average_Rain_prediction': round(entry['average_Rain_prediction'], 2),
            }
            for entry in sdata
        ]

        return Response(rounded_data)


    

















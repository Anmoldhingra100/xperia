from rest_framework import serializers
from solar_app.models import MySolarrr,solargeneration,Temperature,Efficiency,Humidity,Performance,UV_Indexx,Production,Irradiance,Sales_and_revenue,weather
from rest_framework import serializers
from .models import Solar_Plant

class EnergyDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = MySolarrr
        fields = '__all__'



class MySolarrrSerializer(serializers.ModelSerializer):
    class Meta:
        model = MySolarrr
        fields = '__all__'



class UV_IndexxSerializer(serializers.ModelSerializer):
    class Meta:
        model = UV_Indexx
        fields = '__all__'


class IrradianceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Irradiance
        fields = '__all__'



class HumiditySerializer(serializers.ModelSerializer):
    class Meta:
        model = Humidity
        fields = '__all__' 



class EfficiencySerializer(serializers.ModelSerializer):
    class Meta:
        model = Efficiency
        fields = '__all__'





class TemperatureSerializer(serializers.ModelSerializer):
    class Meta:
        model = Temperature
        fields = ['date', '_04_00', '_05_00', '_06_00', '_07_00', '_08_00', '_09_00', '_10_00', '_11_00', '_12_00', '_13_00', '_14_00', '_15_00', '_16_00', '_17_00', '_18_00', '_19_00', '_20_00']

class ProductionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Production
        fields = '__all__'


class PerformanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Performance
        fields = ['date', '_04_00', '_05_00', '_06_00', '_07_00', '_08_00', '_09_00',
                  '_10_00', '_11_00', '_12_00', '_13_00', '_14_00', '_15_00', '_16_00',
                  '_17_00', '_18_00', '_19_00', '_20_00']


class solargenerationSerializer(serializers.ModelSerializer):
    class Meta:
        model = solargeneration
        fields = ['date', '_04_00', '_05_00', '_06_00', '_07_00', '_08_00', '_09_00',
                  '_10_00', '_11_00', '_12_00', '_13_00', '_14_00', '_15_00', '_16_00',
                  '_17_00', '_18_00', '_19_00', '_20_00']



 




class DateField(serializers.DateField):
    def to_representation(self, value):
        if isinstance(value, datetime):
            value = value.date()  # Convert datetime to date
        return super().to_representation(value)


class AggregatedSolarPlantSerializer(serializers.Serializer):
    date = serializers.DateField()
    total_energy_distribution = serializers.IntegerField()
    total_energy_consumption = serializers.FloatField()
    total_energy_generation = serializers.IntegerField()
    total_invertor_performance = serializers.IntegerField()
    total_fault_report = serializers.IntegerField()


class SolarPlantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Solar_Plant
        fields = '__all__'
    
class SalesandrevenueSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sales_and_revenue
        fields = '__all__'



class weatherSerializer(serializers.ModelSerializer):
     class Meta:
        model = weather
        fields = '__all__'


    
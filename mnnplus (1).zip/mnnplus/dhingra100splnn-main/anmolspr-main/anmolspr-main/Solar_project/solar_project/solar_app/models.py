from django.db.models import Sum
from django.utils import timezone
from django.db.models.functions import TruncWeek
from django.db import models
from datetime import timedelta



class MySolarrr(models.Model):
    date = models.DateField()
    sales = models.FloatField(default=0)
    invertor_power_conversion = models.FloatField(default=0)
    invertor1 = models.FloatField(default=0)
    invertor2 = models.FloatField(default=0)
    invertor3 = models.FloatField(default=0)
    faulty_panels = models.FloatField(default=0)
    working_panels = models.FloatField(default=0)
    weather_prediction = models.FloatField(default=0)
    maintainance_cost = models.FloatField(default=0)
    Profit_and_loss = models.FloatField(default=0)
    Rain_prediction = models.FloatField(default=0)
    Energy_Distribution = models.FloatField(default=0)
    production = models.FloatField(default=0)
    



class solargeneration(models.Model):

    date = models.DateField()
    _04_00 = models.FloatField(default=0)
    _05_00 = models.FloatField(default=0)
    _06_00 = models.FloatField(default=0)
    _07_00 = models.FloatField(default=0)
    _08_00 = models.FloatField(default=0)
    _09_00 = models.FloatField(default=0)
    _10_00 = models.FloatField(default=0)
    _11_00 = models.FloatField(default=0)
    _12_00 = models.FloatField(default=0)
    _13_00 = models.FloatField(default=0)
    _14_00 = models.FloatField(default=0)
    _15_00 = models.FloatField(default=0)
    _16_00 = models.FloatField(default=0)
    _17_00 = models.FloatField(default=0)
    _18_00 = models.FloatField(default=0)
    _19_00 = models.FloatField(default=0)
    _20_00 = models.FloatField(default=0)




class Production(models.Model):

    date = models.DateField()
    _04_00 = models.FloatField(default=0)
    _05_00 = models.FloatField(default=0)
    _06_00 = models.FloatField(default=0)
    _07_00 = models.FloatField(default=0)
    _08_00 = models.FloatField(default=0)
    _09_00 = models.FloatField(default=0)
    _10_00 = models.FloatField(default=0)
    _11_00 = models.FloatField(default=0)
    _12_00 = models.FloatField(default=0)
    _13_00 = models.FloatField(default=0)
    _14_00 = models.FloatField(default=0)
    _15_00 = models.FloatField(default=0)
    _16_00 = models.FloatField(default=0)
    _17_00 = models.FloatField(default=0)
    _18_00 = models.FloatField(default=0)
    _19_00 = models.FloatField(default=0)
    _20_00 = models.FloatField(default=0)


class Performance(models.Model):

    date = models.DateField()
    _04_00 = models.FloatField(default=0)
    _05_00 = models.FloatField(default=0)
    _06_00 = models.FloatField(default=0)
    _07_00 = models.FloatField(default=0)
    _08_00 = models.FloatField(default=0)
    _09_00 = models.FloatField(default=0)
    _10_00 = models.FloatField(default=0)
    _11_00 = models.FloatField(default=0)
    _12_00 = models.FloatField(default=0)
    _13_00 = models.FloatField(default=0)
    _14_00 = models.FloatField(default=0)
    _15_00 = models.FloatField(default=0)
    _16_00 = models.FloatField(default=0)
    _17_00 = models.FloatField(default=0)
    _18_00 = models.FloatField(default=0)
    _19_00 = models.FloatField(default=0)
    _20_00 = models.FloatField(default=0)

class Temperature(models.Model):

    date = models.DateField()
    _04_00 = models.FloatField(default=0)
    _05_00 = models.FloatField(default=0)
    _06_00 = models.FloatField(default=0)
    _07_00 = models.FloatField(default=0)
    _08_00 = models.FloatField(default=0)
    _09_00 = models.FloatField(default=0)
    _10_00 = models.FloatField(default=0)
    _11_00 = models.FloatField(default=0)
    _12_00 = models.FloatField(default=0)
    _13_00 = models.FloatField(default=0)
    _14_00 = models.FloatField(default=0)
    _15_00 = models.FloatField(default=0)
    _16_00 = models.FloatField(default=0)
    _17_00 = models.FloatField(default=0)
    _18_00 = models.FloatField(default=0)
    _19_00 = models.FloatField(default=0)
    _20_00 = models.FloatField(default=0)
    



class Humidity(models.Model):

    date = models.DateField()
    _04_00 = models.FloatField(default=0)
    _05_00 = models.FloatField(default=0)
    _06_00 = models.FloatField(default=0)
    _07_00 = models.FloatField(default=0)
    _08_00 = models.FloatField(default=0)
    _09_00 = models.FloatField(default=0)
    _10_00 = models.FloatField(default=0)
    _11_00 = models.FloatField(default=0)
    _12_00 = models.FloatField(default=0)
    _13_00 = models.FloatField(default=0)
    _14_00 = models.FloatField(default=0)
    _15_00 = models.FloatField(default=0)
    _16_00 = models.FloatField(default=0)
    _17_00 = models.FloatField(default=0)
    _18_00 = models.FloatField(default=0)
    _19_00 = models.FloatField(default=0)
    _20_00 = models.FloatField(default=0)


    def __str__(self):
        return f"Humidity data for {self.date}"




class Efficiency(models.Model):

    date = models.DateField()
    _04_00 = models.FloatField(default=0)
    _05_00 = models.FloatField(default=0)
    _06_00 = models.FloatField(default=0)
    _07_00 = models.FloatField(default=0)
    _08_00 = models.FloatField(default=0)
    _09_00 = models.FloatField(default=0)
    _10_00 = models.FloatField(default=0)
    _11_00 = models.FloatField(default=0)
    _12_00 = models.FloatField(default=0)
    _13_00 = models.FloatField(default=0)
    _14_00 = models.FloatField(default=0)
    _15_00 = models.FloatField(default=0)
    _16_00 = models.FloatField(default=0)
    _17_00 = models.FloatField(default=0)
    _18_00 = models.FloatField(default=0)
    _19_00 = models.FloatField(default=0)
    _20_00 = models.FloatField(default=0)
    



class UV_Indexx(models.Model):

    date = models.DateField()
    _04_00 = models.FloatField(default=0)
    _05_00 = models.FloatField(default=0)
    _06_00 = models.FloatField(default=0)
    _07_00 = models.FloatField(default=0)
    _08_00 = models.FloatField(default=0)
    _09_00 = models.FloatField(default=0)
    _10_00 = models.FloatField(default=0)
    _11_00 = models.FloatField(default=0)
    _12_00 = models.FloatField(default=0)
    _13_00 = models.FloatField(default=0)
    _14_00 = models.FloatField(default=0)
    _15_00 = models.FloatField(default=0)
    _16_00 = models.FloatField(default=0)
    _17_00 = models.FloatField(default=0)
    _18_00 = models.FloatField(default=0)
    _19_00 = models.FloatField(default=0)
    _20_00 = models.FloatField(default=0)

    


class Irradiance(models.Model):

    date = models.DateField()
    _04_00 = models.FloatField(default=0)
    _05_00 = models.FloatField(default=0)
    _06_00 = models.FloatField(default=0)
    _07_00 = models.FloatField(default=0)
    _08_00 = models.FloatField(default=0)
    _09_00 = models.FloatField(default=0)
    _10_00 = models.FloatField(default=0)
    _11_00 = models.FloatField(default=0)
    _12_00 = models.FloatField(default=0)
    _13_00 = models.FloatField(default=0)
    _14_00 = models.FloatField(default=0)
    _15_00 = models.FloatField(default=0)
    _16_00 = models.FloatField(default=0)
    _17_00 = models.FloatField(default=0)
    _18_00 = models.FloatField(default=0)
    _19_00 = models.FloatField(default=0)
    _20_00 = models.FloatField(default=0)










class Solar_Plant(models.Model):
    date = models.DateTimeField()
    Energy_Distribution = models.FloatField(default=0)
    Energy_Consumption = models.FloatField(default=0)
    Energy_generation = models.FloatField(default=0)
    Invertor_performance = models.FloatField(default=0)
    Fault_report = models.FloatField(default=0)
    


class weather(models.Model):
    date = models.DateTimeField()
    Humidity = models.FloatField()
    UV_Index = models.FloatField()
    Temperature = models.FloatField() 
    Irradiance = models.FloatField()
    Rain_prediction = models.FloatField(default=0)



class Sales_and_revenue(models.Model):
    date = models.DateField()
    Revenue = models.FloatField()
    Sales = models.FloatField()
    Profit = models.FloatField()
    Losses = models.FloatField()
    Maintainance_cost = models.FloatField()